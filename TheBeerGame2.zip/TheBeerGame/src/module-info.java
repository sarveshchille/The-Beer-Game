
module TheBeerGame {
	requires jdk.httpserver;
	requires com.google.gson;

}