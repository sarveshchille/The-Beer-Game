
module TheBeerGame {
	requires jdk.httpserver;
}